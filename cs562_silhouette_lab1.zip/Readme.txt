[ ] 1 - Compute adjacency data of the mesh (Line 217 in MeshData.cpp)
[ ] 2 - Modify geometry.gs shader to create the edges
[ ] 3 - Modify vertexColor.vs and fragmentColor.fs to have toon shading