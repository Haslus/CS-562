#version 430

layout( location = 0 ) out vec4 FragColor;

const vec3 LightPosition = vec3(10.0f, 10.0f, 10.0f);

void main()
{   
    float diffuseFactor = 1.0f;

    FragColor = diffuseFactor * vec4(1,0,0,1);
}