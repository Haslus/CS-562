#version 430

layout( location = 0 ) out vec4 FragColor;

void main()
{   
    FragColor = vec4(0.0, 0.0, 0.0, 1.0);
}